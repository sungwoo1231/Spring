package com.dw.thridapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThridappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThridappApplication.class, args);
	}

}

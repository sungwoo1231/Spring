package com.dw.thridapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThridappApplicationTests {

	@Test
	void contextLoads() {
	}

}
